package t4a1;

import java.util.Scanner;

/**
 * *
 * @author Raul
 */
public class T4A1 {

    public static void main(String[] args) {
        //ejercicio1();
        //ejercicio2();
        //ejercicio3();
        ejercicio4();
    }

    /**
     * 1. Escribir un programa que solicite un número positivo y nos muestre
     * desde 1 hasta el valor ingresado de uno en uno. Ejemplo: Si ingresamos 30
     * se debe mostrar en pantalla los números del 1 al 30.*
     */
    public static void ejercicio1() {
        Scanner obj = new Scanner(System.in);

        int numero = 0;

        System.out.println("Hasta donde quieres llegar");
        int limite = obj.nextInt();
        if (limite <= 0) {
            System.out.println("Ingrese un numero correcto");
        } else {
            while (numero < limite) {
                numero++;
                System.out.println(numero);
            }
        }
    }

    public static void ejercicio2() {
        Scanner obj = new Scanner(System.in);

        /*2. Una maquiladora confecciona pantalones y recibe un lote de N piezas para un cliente X. 
        Crear un programa en Java que solicite la cantidad de piezas a confeccionar y luego se ingrese las respectivas tallas que pueden ser S, M, L y XL. 
        Luego, imprimir en pantalla la cantidad de piezas confeccionadas por talla.*/
        System.out.println("Piezas a confeccionar");//diagonal invertida t
        int piezas = obj.nextInt();
        int n = 0, tallaS = 0, tallaM = 0, tallaL = 0, tallaXL = 0;

        while (n < piezas) {
            n++;

            System.out.println("\nTalla");
            String talla = obj.next();

            if (talla.equals("S") || talla.equals("s")) {
                tallaS++;
            } else if (talla.equals("M") || talla.equals("m")) {
                tallaM++;
            } else if (talla.equals("L") || talla.equals("l")) {
                tallaL++;
            } else if (talla.equals("XL") || talla.equals("xl")||talla.equals("Xl")||talla.equals("xL1")) {
                tallaXL++;
            }
        }
        System.out.println("Talla M: " + tallaS+
                "\nTalla S: " + tallaM+
                "\nTalla L: " + tallaL+
                "\nTalla XL: " + tallaXL);


    }
    public static void ejercicio3(){
        Scanner obj = new Scanner(System.in);
        
        //3. Escribir un programa en Java que solicite N calificaciones de estudiantes en una escala del 0 al 100 y que informe 
        //cuántos tienen calificación mayor o igual a 70 y cuántos tienen una calificación menor. 
        int n=0, calificacion, mayor=0, menor=0;
        System.out.println("ingrese la cantidad de calificaciones");
        int nCalificacion=obj.nextInt();
        
        while(n<nCalificacion){
            n++;
            
            System.out.println("Ingrese la calificación en una escala del 0 al 100: ");
            calificacion=obj.nextInt();
            
            if(calificacion>=70 && calificacion<=100){
                mayor++;
            }
            else if(calificacion>=0 && calificacion<69){
                menor++;
            }
            else{
                System.out.println("Ingrese una calificacion correcta");
            }
        }
        System.out.println("Calificación mayor a 70: "+mayor
                +"\nCalificación menor a 70: "+menor);
    }
    public static void ejercicio4(){
        Scanner obj = new Scanner(System.in);
        /**4. Escribir un programa en Java que imprima los múltiplos del número que indique el usuario hasta la cantidad deseada. 
         * El usuario debe indicar el múltiplo y el número hasta el cual quiere llegar. Ejemplo:

	Múltiplo: 3
	Quiero llegar hasta: 20
	Resultado: 3, 6, 9, 12, 15, 18*/
        
        int multiplo, limite, n=0, numero=1, multi;
        System.out.println("Multiplo ");
        multiplo=obj.nextInt();
        
        System.out.println("Quiero llegar hasta ");
        limite=obj.nextInt();
        
        while(n<limite){
            n++;
            
            multi=multiplo*numero;
            
            System.out.println(numero+".-"+multi);
            
            numero++;
        
        }
                
    } 

}
